
var textdata = [];

textdata[0] = "Get Ready";
textdata[1] = "Tap Screen To Play";
textdata[2] = "Please switch to portrait mode";
textdata[3] = "Game Over";


